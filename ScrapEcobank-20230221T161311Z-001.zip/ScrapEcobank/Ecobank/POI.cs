﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.Extensions;


namespace Ecobank
{
    class POI
    {
        public string poiName;
        public string address;
        public string email;
        public string phone;
        public string openingHours;
        public string coordinates;

        public void ScrapeChrome()
        {
            ChromeDriver driver = new ChromeDriver("D:\\Install");
            driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");

            //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            List<string> countryListALL = driver.FindElementById("sl_country_codes").FindElements(By.TagName("option")).Select(t => t.Text).ToList();

            Console.WriteLine(DateTime.Now);

            driver.Quit();


            //countryListALL.RemoveRange(1, 32); //////////// удалить потом
            //List<string> countryList1 = countryListALL;//////////// удалить потом
            //List<string> countryList1 = new List<string>() { "Congo", "Kenya", "Tanzania", "The Gambia", "Nigeria" };//////////// удалить потом

            List<string> countryList1 = countryListALL.GetRange(0, 1);
            countryListALL.RemoveRange(0, 1);
            List<string> countryList2 = countryListALL.GetRange(0, 15);
            countryListALL.RemoveRange(0, 15);
            List<string> countryList3 = countryListALL;
            countryListALL = null;

            ////List<string> countryList4 = countryListALL.GetRange(0, 6);
            ////countryListALL.RemoveRange(0, 6);
            ////List<string> countryList5 = countryListALL;
            //countryListALL = null;

            //Task tast1 = Task.Factory.StartNew(() => ScrapeChrome(1, countryList1)); ///надёжней вроде (Рома)
            Task task1 = new Task(() => ScrapeChrome(1, countryList1));
            task1.Start();

            Task task2 = new Task(() => ScrapeChrome(2, countryList2));
            //task2.Start();

            Task task3 = new Task(() => ScrapeChrome(3, countryList3));
            //task3.Start();


            //Task task4 = new Task(() => ScrapeChrome(4, countryList2));
            //task4.Start();

            //Task task5 = new Task(() => ScrapeChrome(5, countryList2));
            //task5.Start();

            Task.WaitAll(task1, task2, task3);
            ////можно по отдельности ждать:
            //task1.Wait();
            //task2.Wait();
            //task3.Wait();

            //task4.Wait();
            //task5.Wait();

            Console.WriteLine(DateTime.Now);
            Console.ReadKey();
        }


        public void ScrapeChrome(int taskId, List<string> countryList)
        {
            ChromeDriver driver = new ChromeDriver("D:\\Install");

            driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");

            //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            string pathForExceptions2 = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\Exceptions2.txt";

            //Console.WriteLine("close feedback and press a button in Console");
            //Console.ReadKey();

            //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            //WebDriver www = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            foreach (var country in countryList)
            {
                //Thread.Sleep(4000);

                try
                {

                    IWebElement inputBoxCountry = driver.FindElementById("sl_country_codes");
                    //wait.Until(ExpectedConditions.ElementToBeClickable(inputBoxCountry));

                    //Thread.Sleep(4000);

                    Actions actions = new Actions(driver);
                    actions.MoveToElement(inputBoxCountry);
                    //Thread.Sleep(1000);
                    actions.Perform();
                    //Thread.Sleep(2000);

                    ////не работает !!! ???
                    //SelectElement clickCity = new SelectElement(inputBox);
                    //clickCity.SelectByText(country);
                    //inputBox.SendKeys(Keys.Enter);  

                    ////можно так:
                    inputBoxCountry.Click();
                    //Thread.Sleep(2000);
                    inputBoxCountry.SendKeys(country + Keys.Enter);
                    //inputBox.SendKeys(Keys.Enter);
                    //Thread.Sleep(3000);
                }
                catch
                {
                    Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - НЕ ВЫБРАН/КЛИКНУТ country ++++++++++++++++++++++++++++++++++");
                    File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - НЕ ВЫБРАН/КЛИКНУТ country ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

                }


                /////////////////////////////////

                List<string> facilityList = driver.FindElementById("sl_btype").FindElements(By.TagName("option")).Select(t => t.Text).Reverse().ToList();



                foreach (var facility in facilityList)
                {
                mark2:
                    try
                    {
                        try
                        {
                            //Thread.Sleep(2000);
                            IWebElement inputFacilityType = driver.FindElementById("sl_btype");
                            //wait.Until(ExpectedConditions.ElementToBeClickable(inputFacilityType));

                            


                            Actions actions2 = new Actions(driver);
                            actions2.MoveToElement(inputFacilityType);
                            //Thread.Sleep(1000);
                            actions2.Perform();
                            //Thread.Sleep(1000);

                            inputFacilityType.Click();
                            //Thread.Sleep(1000);
                            inputFacilityType.SendKeys(facility);
                            //Thread.Sleep(1000);
                            inputFacilityType.SendKeys(Keys.Enter);
                            //Thread.Sleep(4000);////было 4000
                        }
                        catch
                        {
                            Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ ВЫБРАН/КЛИКНУТ facility ++++++++++++++++++++++++++++++++++");
                            File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ ВЫБРАН/КЛИКНУТ facility ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

                        }



                    mark:
                        List<string> cityList;

                        try
                        {
                            //cityList = driver.FindElementById("main_sl_cities").FindElements(By.TagName("option")).Select(t => t.Text).ToList();
                            IWebElement cityList1 = driver.FindElementById("main_sl_cities");
                            cityList = driver.FindElementById("main_sl_cities").FindElements(By.TagName("option")).Select(t => t.Text).ToList();
                            //wait.Until(ExpectedConditions.ElementToBeClickable(cityList1));
                        }
                        catch
                        {
                            Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility}  НЕ СОЗДАН cityList ++++++++++++++++++++++++++++++++++");
                            File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ СОЗДАН cityList ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

                            //Thread.Sleep(3000);
                            goto mark;
                        }

                        foreach (var city in cityList)
                        {
                            //Thread.Sleep(4000);////было 4000

                            try
                            {
                                IWebElement inputBoxCity = driver.FindElementById("main_sl_cities");
                                Actions actions3 = new Actions(driver);
                                actions3.MoveToElement(inputBoxCity);
                                //Thread.Sleep(1000);
                                actions3.Perform();
                                //Thread.Sleep(1000);

                                inputBoxCity.Click();
                                //Thread.Sleep(2000);
                                inputBoxCity.SendKeys(city + Keys.Enter);
                                //Thread.Sleep(3000); ////было 3000
                            }
                            catch
                            {
                                Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - {city}  НЕ ВЫБРАН/КЛИКНУТ city ++++++++++++++++++++++++++++++++++");
                                File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++{country} - {facility} - {city}  - НЕ ВЫБРАН/КЛИКНУТ city +++++++++++++++++++++++++++++{Environment.NewLine}");

                                ////driver.SwitchTo().ParentFrame();
                            }

                            SelectElement value = new SelectElement(driver.FindElementById("main_sl_cities"));
                            string currentCity = value.SelectedOption.Text;
                            //if (currentCity != city)
                            //{
                            //    continue;
                            //}
                            IWebElement resultsInFacility = driver.FindElementById("searchResult");
                            string resultsInCityText = resultsInFacility.Text;


                            List<IWebElement> poiContainer = driver.FindElementsByTagName("div").Where(d => d.GetAttribute("id").Contains("locationid_")).ToList();

                            //List<string> poiContainer = driver.FindElementById("locations_table").FindElements(By.TagName("h2")).Select(t => t.Text).ToList();
                            ////string phone = driver.FindElement(By.ClassName("contact-block-text")).FindElement(By.TagName("p")).Text;
                            ////string address = driver.FindElement(By.TagName("address")).Text;

                            string pathForWrite = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\pois.txt";
                            string pathForExceptions = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\Exceptions.txt";


                            foreach (var container in poiContainer)
                            {

                                POI poi = new POI();
                                try
                                {
                                    poi.poiName = container.FindElement(By.TagName("h2")).Text;
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: poiName\t{country}\t{city}\t{facility}");
                                    File.AppendAllText(pathForExceptions, $"Check: poiName\t{country}\t{city}\t{facility}{Environment.NewLine}");

                                }
                                try
                                {
                                    poi.address = container.FindElement(By.TagName("address")).Text;
                                    poi.address = poi.address.Replace($"{Environment.NewLine}", ", ").Trim().Trim(',');
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: address\t{country}\t{city}\t{facility}\t{poi.poiName}");
                                    File.AppendAllText(pathForExceptions, $"Check: address\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
                                }
                                try
                                {
                                    poi.email = container.FindElements(By.TagName("a")).First(d => !String.IsNullOrEmpty(d.GetAttribute("href")) && d.GetAttribute("href").Contains("mailto")).Text.ToLower();
                                    //poi.email = poi.email.Substring(0, 1).ToUpper() + poi.email.Substring(1, poi.email.Length - 1).ToLower();
                                    //List<IWebElement> email = container.FindElements(By.TagName("a")).Where(d => !String.IsNullOrEmpty(d.GetAttribute("href")) &&  d.GetAttribute("href").Contains("mailto")).ToList();
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: email\t{country}\t{city}\t{facility}\t{poi.poiName}");
                                    File.AppendAllText(pathForExceptions, $"Check: email\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");

                                }
                                try
                                {
                                    poi.phone = container.FindElements(By.TagName("a")).First(d => !String.IsNullOrEmpty(d.GetAttribute("href")) && d.GetAttribute("href").Contains("tel")).Text;
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: phone\t{country}\t{city}\t{facility}\t{poi.poiName}");
                                    File.AppendAllText(pathForExceptions, $"Check: phone\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
                                }
                                try
                                {
                                    poi.openingHours = container.FindElement(By.CssSelector(".times")).FindElement(By.TagName("ul")).Text;
                                    poi.openingHours = poi.openingHours.Replace($"{Environment.NewLine}", "\t");
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: openingHours\t{country}\t{city}\t{facility}\t{poi.poiName}");
                                    File.AppendAllText(pathForExceptions, $"Check: openingHours\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
                                }

                                //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                                //string title = (string)js.ExecuteScript("return document.title");

                                //string mapCenter = (string)js.ExecuteScript("map._lastCenter");

                                //Console.WriteLine(title);

                                try
                                {
                                    IWebElement viewOnMapLink = container.FindElement(By.LinkText("View on map"));
                                    //var element = driver.FindElement(By.LinkText("View on map"));
                                    Actions actions4 = new Actions(driver);
                                    actions4.MoveToElement(viewOnMapLink);
                                    //Thread.Sleep(1000);
                                    actions4.Perform();
                                    //Thread.Sleep(1000);

                                    try
                                    {
                                        //Thread.Sleep(2000);
                                        IWebElement feedback = driver.FindElementByCssSelector(".btl.bt-times");
                                        feedback.Click();
                                        Console.WriteLine("Всплывающее окно закрыто");

                                        //Thread.Sleep(2000);
                                    }
                                    catch
                                    {

                                    }

                                    viewOnMapLink.Click();
                                    //Thread.Sleep(4000);
                                    poi.coordinates = driver.FindElementByCssSelector(".leaflet-popup-content").FindElement(By.PartialLinkText("google")).GetAttribute("href");
                                    poi.coordinates = poi.coordinates.Substring(poi.coordinates.IndexOf("=") + 1).Replace(",", "\t");

                                    ////// закрытие всплывающего окна информации ПОИ
                                    //IWebElement closePopUpWindow = driver.FindElement(By.CssSelector(".leaflet-popup-close-button"));
                                    //Thread.Sleep(2000);
                                    //closePopUpWindow.Click();
                                    //Thread.Sleep(2000);

                                    ////if (string.IsNullOrEmpty(poi.coordinates))
                                    ////{
                                    ////// координаты центра карты - что-то не всегда работает
                                    //driver.ExecuteJavaScript("(()=>{map.zoomControl._zoomOutButton.click();})();");
                                    //Thread.Sleep(500);
                                    //driver.ExecuteJavaScript("(()=>{map.zoomControl._zoomInButton.click ();})();");
                                    //Thread.Sleep(500);
                                    //string mapCenter = driver.ExecuteJavaScript<string>("(()=>map.getCenter())();");

                                    ////string mapCenter = driver.ExecuteJavaScript<string>("(()=>{map.zoomControl._zoomOutButton.click();map.zoomControl._zoomInButton.click();map._lastCenter;})();");
                                    //////или так:
                                    //////IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                                    //////string mapCenter = (string)js.ExecuteScript("(()=>{map.zoomControl._zoomOutButton.click();map.zoomControl._zoomInButton.click();map._lastCenter;})();");
                                    ////}
                                    //Thread.Sleep(2000);
                                }
                                catch
                                {
                                    Console.WriteLine($"Check: coordinates\t{country}\t{city}\t{facility}\t{poi.poiName}");
                                    File.AppendAllText(pathForExceptions, $"Check: coordinates\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");

                                }


                                var consLock = new object();
                                lock (consLock)
                                {
                                    //Console.WriteLine(container.Text);
                                    //Console.WriteLine($"{country}\t{city}\t{facility}\t{poiName}\t{address}\t{email}\t{phone}");
                                }

                                File.AppendAllText(pathForWrite, $"{country}\t{city}\t{facility}\t{poi.poiName}\t{poi.address}\t{poi.email}\t{poi.phone}\t{poi.openingHours}\t{poi.coordinates}{Environment.NewLine}");
                                //File.AppendAllText(pathForWrite, $"{container.Text.Replace('\n', '\t')}{Environment.NewLine}");
                            }
                            try
                            {
                                IWebElement allLocator = driver.FindElementById("EmptyPanel").FindElement(By.TagName("h1"));
                                Actions actions5 = new Actions(driver);
                                actions5.MoveToElement(allLocator);
                                //Thread.Sleep(1000);
                                actions5.Perform();
                                //Thread.Sleep(1000);
                            }
                            catch
                            {
                                Console.WriteLine("++++++++++++++++++++++++++++++++++ НЕ ПЕРЕШЁЛ К \"Locator\" ++++++++++++++++++++++++++++++++++");
                            }


                            //Console.WriteLine($"{city}\t{facility}\t{resultsInCityText}");
                            //File.AppendAllText(pathForWrite, $"\t\t\t\t{city}\t{facility}\t{resultsInCityText}{Environment.NewLine}");

                            //Console.WriteLine($"Ошибка: {country}\t{city}\t{facility}");

                        }
                    }
                    catch
                    {
                        Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - ЧТО-ТО ПОШЛО НЕ ТАК ++++++++++++++++++++++++++++++++++");
                        File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - ЧТО-ТО ПОШЛО НЕ ТАК  ++++++++++++++++++++++++++++++++++{Environment.NewLine}");
                        //Thread.Sleep(3000);

                        IWebElement allLocator2 = driver.FindElementById("EmptyPanel").FindElement(By.TagName("h1"));
                        Actions actions6 = new Actions(driver);
                        actions6.MoveToElement(allLocator2);
                        //Thread.Sleep(1000);
                        actions6.Perform();
                        //Thread.Sleep(1000);
                        goto mark2;
                    }
                }
            }
        }

    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //class POI
    //{
    //    public string poiName;
    //    public string address;
    //    public string email;
    //    public string phone;
    //    public string openingHours;
    //    public string coordinates;



    //    public void ScrapeChrome()
    //    {
    //        ChromeDriver driver = new ChromeDriver("D:\\Install");
    //        driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");

    //        List<string> countryListALL = driver.FindElementById("sl_country_codes").FindElements(By.TagName("option")).Select(t => t.Text).ToList();

    //        Console.WriteLine(DateTime.Now);

    //        driver.Quit();


    //        //countryListALL.RemoveRange(1, 32); //////////// удалить потом
    //        //List<string> countryList1 = countryListALL;//////////// удалить потом
    //        //List<string> countryList1 = new List<string>() { "Congo", "Kenya", "Tanzania", "The Gambia", "Nigeria" };//////////// удалить потом

    //        List<string> countryList1 = countryListALL.GetRange(0, 1);
    //        countryListALL.RemoveRange(0, 1);
    //        List<string> countryList2 = countryListALL.GetRange(0, 15);
    //        countryListALL.RemoveRange(0, 15);
    //        List<string> countryList3 = countryListALL;
    //        countryListALL = null;

    //        ////List<string> countryList4 = countryListALL.GetRange(0, 6);
    //        ////countryListALL.RemoveRange(0, 6);
    //        ////List<string> countryList5 = countryListALL;
    //        //countryListALL = null;

    //        //Task tast1 = Task.Factory.StartNew(() => ScrapeChrome(1, countryList1)); ///надёжней вроде (Рома)
    //        Task task1 = new Task(() => ScrapeChrome(1, countryList1));
    //        task1.Start();

    //        Task task2 = new Task(() => ScrapeChrome(2, countryList2));
    //        task2.Start();

    //        Task task3 = new Task(() => ScrapeChrome(3, countryList3));
    //        task3.Start();


    //        //Task task4 = new Task(() => ScrapeChrome(4, countryList2));
    //        //task4.Start();

    //        //Task task5 = new Task(() => ScrapeChrome(5, countryList2));
    //        //task5.Start();

    //        Task.WaitAll(task1, task2, task3);
    //        ////можно по отдельности ждать:
    //        //task1.Wait();
    //        //task2.Wait();
    //        //task3.Wait();

    //        //task4.Wait();
    //        //task5.Wait();

    //        Console.WriteLine(DateTime.Now);
    //        Console.ReadKey();
    //    }


    //    public void ScrapeChrome(int taskId, List<string> countryList)
    //    {
    //        ChromeDriver driver = new ChromeDriver("D:\\Install");

    //        driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");

    //        string pathForExceptions2 = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\Exceptions2.txt";

    //        //Console.WriteLine("close feedback and press a button in Console");
    //        //Console.ReadKey();

    //        foreach (var country in countryList)
    //        {
    //            Thread.Sleep(4000);

    //            try
    //            {
    //                IWebElement inputBoxCountry = driver.FindElementById("sl_country_codes");
    //                Thread.Sleep(4000);

    //                Actions actions = new Actions(driver);
    //                actions.MoveToElement(inputBoxCountry);
    //                Thread.Sleep(1000);
    //                actions.Perform();
    //                Thread.Sleep(2000);

    //                ////не работает !!! ???
    //                //SelectElement clickCity = new SelectElement(inputBox);
    //                //clickCity.SelectByText(country);
    //                //inputBox.SendKeys(Keys.Enter);  

    //                ////можно так:
    //                inputBoxCountry.Click();
    //                Thread.Sleep(2000);
    //                inputBoxCountry.SendKeys(country + Keys.Enter);
    //                //inputBox.SendKeys(Keys.Enter);
    //                Thread.Sleep(3000);
    //            }
    //            catch
    //            {
    //                Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - НЕ ВЫБРАН/КЛИКНУТ country ++++++++++++++++++++++++++++++++++");
    //                File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - НЕ ВЫБРАН/КЛИКНУТ country ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

    //            }


    //            /////////////////////////////////

    //            List<string> facilityList = driver.FindElementById("sl_btype").FindElements(By.TagName("option")).Select(t => t.Text).Reverse().ToList();



    //            foreach (var facility in facilityList)
    //            {
    //            mark2:
    //                try
    //                {
    //                    try
    //                    {
    //                        Thread.Sleep(2000);
    //                        IWebElement inputFacilityType = driver.FindElementById("sl_btype");

    //                        Actions actions2 = new Actions(driver);
    //                        actions2.MoveToElement(inputFacilityType);
    //                        Thread.Sleep(1000);
    //                        actions2.Perform();
    //                        Thread.Sleep(1000);

    //                        inputFacilityType.Click();
    //                        Thread.Sleep(1000);
    //                        inputFacilityType.SendKeys(facility);
    //                        Thread.Sleep(1000);
    //                        inputFacilityType.SendKeys(Keys.Enter);
    //                        Thread.Sleep(4000);////было 4000
    //                    }
    //                    catch
    //                    {
    //                        Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ ВЫБРАН/КЛИКНУТ facility ++++++++++++++++++++++++++++++++++");
    //                        File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ ВЫБРАН/КЛИКНУТ facility ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

    //                    }



    //                mark:
    //                    List<string> cityList;

    //                    try
    //                    {
    //                        cityList = driver.FindElementById("main_sl_cities").FindElements(By.TagName("option")).Select(t => t.Text).ToList();
    //                    }
    //                    catch
    //                    {
    //                        Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility}  НЕ СОЗДАН cityList ++++++++++++++++++++++++++++++++++");
    //                        File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - НЕ СОЗДАН cityList ++++++++++++++++++++++++++++++++++{Environment.NewLine}");

    //                        Thread.Sleep(3000);
    //                        goto mark;
    //                    }

    //                    foreach (var city in cityList)
    //                    {
    //                        Thread.Sleep(4000);////было 4000

    //                        try
    //                        {
    //                            IWebElement inputBoxCity = driver.FindElementById("main_sl_cities");
    //                            Actions actions3 = new Actions(driver);
    //                            actions3.MoveToElement(inputBoxCity);
    //                            Thread.Sleep(1000);
    //                            actions3.Perform();
    //                            Thread.Sleep(1000);

    //                            inputBoxCity.Click();
    //                            Thread.Sleep(2000);
    //                            inputBoxCity.SendKeys(city + Keys.Enter);
    //                            Thread.Sleep(3000); ////было 3000
    //                        }
    //                        catch
    //                        {
    //                            Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - {city}  НЕ ВЫБРАН/КЛИКНУТ city ++++++++++++++++++++++++++++++++++");
    //                            File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++{country} - {facility} - {city}  - НЕ ВЫБРАН/КЛИКНУТ city +++++++++++++++++++++++++++++{Environment.NewLine}");

    //                            ////driver.SwitchTo().ParentFrame();
    //                        }

    //                        SelectElement value = new SelectElement(driver.FindElementById("main_sl_cities"));
    //                        string currentCity = value.SelectedOption.Text;
    //                        //if (currentCity != city)
    //                        //{
    //                        //    continue;
    //                        //}
    //                        IWebElement resultsInFacility = driver.FindElementById("searchResult");
    //                        string resultsInCityText = resultsInFacility.Text;


    //                        List<IWebElement> poiContainer = driver.FindElementsByTagName("div").Where(d => d.GetAttribute("id").Contains("locationid_")).ToList();

    //                        //List<string> poiContainer = driver.FindElementById("locations_table").FindElements(By.TagName("h2")).Select(t => t.Text).ToList();
    //                        ////string phone = driver.FindElement(By.ClassName("contact-block-text")).FindElement(By.TagName("p")).Text;
    //                        ////string address = driver.FindElement(By.TagName("address")).Text;

    //                        string pathForWrite = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\pois.txt";
    //                        string pathForExceptions = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\Exceptions.txt";


    //                        foreach (var container in poiContainer)
    //                        {

    //                            POI poi = new POI();
    //                            try
    //                            {
    //                                poi.poiName = container.FindElement(By.TagName("h2")).Text;
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: poiName\t{country}\t{city}\t{facility}");
    //                                File.AppendAllText(pathForExceptions, $"Check: poiName\t{country}\t{city}\t{facility}{Environment.NewLine}");

    //                            }
    //                            try
    //                            {
    //                                poi.address = container.FindElement(By.TagName("address")).Text;
    //                                poi.address = poi.address.Replace($"{Environment.NewLine}", ", ").Trim().Trim(',');
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: address\t{country}\t{city}\t{facility}\t{poi.poiName}");
    //                                File.AppendAllText(pathForExceptions, $"Check: address\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
    //                            }
    //                            try
    //                            {
    //                                poi.email = container.FindElements(By.TagName("a")).First(d => !String.IsNullOrEmpty(d.GetAttribute("href")) && d.GetAttribute("href").Contains("mailto")).Text.ToLower();
    //                                //poi.email = poi.email.Substring(0, 1).ToUpper() + poi.email.Substring(1, poi.email.Length - 1).ToLower();
    //                                //List<IWebElement> email = container.FindElements(By.TagName("a")).Where(d => !String.IsNullOrEmpty(d.GetAttribute("href")) &&  d.GetAttribute("href").Contains("mailto")).ToList();
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: email\t{country}\t{city}\t{facility}\t{poi.poiName}");
    //                                File.AppendAllText(pathForExceptions, $"Check: email\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");

    //                            }
    //                            try
    //                            {
    //                                poi.phone = container.FindElements(By.TagName("a")).First(d => !String.IsNullOrEmpty(d.GetAttribute("href")) && d.GetAttribute("href").Contains("tel")).Text;
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: phone\t{country}\t{city}\t{facility}\t{poi.poiName}");
    //                                File.AppendAllText(pathForExceptions, $"Check: phone\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
    //                            }
    //                            try
    //                            {
    //                                poi.openingHours = container.FindElement(By.CssSelector(".times")).FindElement(By.TagName("ul")).Text;
    //                                poi.openingHours = poi.openingHours.Replace($"{Environment.NewLine}", "\t");
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: openingHours\t{country}\t{city}\t{facility}\t{poi.poiName}");
    //                                File.AppendAllText(pathForExceptions, $"Check: openingHours\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");
    //                            }

    //                            //IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
    //                            //string title = (string)js.ExecuteScript("return document.title");

    //                            //string mapCenter = (string)js.ExecuteScript("map._lastCenter");

    //                            //Console.WriteLine(title);

    //                            try
    //                            {
    //                                IWebElement viewOnMapLink = container.FindElement(By.LinkText("View on map"));
    //                                //var element = driver.FindElement(By.LinkText("View on map"));
    //                                Actions actions4 = new Actions(driver);
    //                                actions4.MoveToElement(viewOnMapLink);
    //                                Thread.Sleep(1000);
    //                                actions4.Perform();
    //                                Thread.Sleep(1000);

    //                                try
    //                                {
    //                                    Thread.Sleep(2000);
    //                                    IWebElement feedback = driver.FindElementByCssSelector(".btl.bt-times");
    //                                    feedback.Click();
    //                                    Console.WriteLine("Всплывающее окно закрыто");

    //                                    Thread.Sleep(2000);
    //                                }
    //                                catch
    //                                {

    //                                }

    //                                viewOnMapLink.Click();
    //                                Thread.Sleep(4000);
    //                                poi.coordinates = driver.FindElementByCssSelector(".leaflet-popup-content").FindElement(By.PartialLinkText("google")).GetAttribute("href");
    //                                poi.coordinates = poi.coordinates.Substring(poi.coordinates.IndexOf("=") + 1).Replace(",", "\t");

    //                                ////// закрытие всплывающего окна информации ПОИ
    //                                //IWebElement closePopUpWindow = driver.FindElement(By.CssSelector(".leaflet-popup-close-button"));
    //                                //Thread.Sleep(2000);
    //                                //closePopUpWindow.Click();
    //                                //Thread.Sleep(2000);

    //                                ////if (string.IsNullOrEmpty(poi.coordinates))
    //                                ////{
    //                                ////// координаты центра карты - что-то не всегда работает
    //                                //driver.ExecuteJavaScript("(()=>{map.zoomControl._zoomOutButton.click();})();");
    //                                //Thread.Sleep(500);
    //                                //driver.ExecuteJavaScript("(()=>{map.zoomControl._zoomInButton.click ();})();");
    //                                //Thread.Sleep(500);
    //                                //string mapCenter = driver.ExecuteJavaScript<string>("(()=>map.getCenter())();");

    //                                ////string mapCenter = driver.ExecuteJavaScript<string>("(()=>{map.zoomControl._zoomOutButton.click();map.zoomControl._zoomInButton.click();map._lastCenter;})();");
    //                                //////или так:
    //                                //////IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
    //                                //////string mapCenter = (string)js.ExecuteScript("(()=>{map.zoomControl._zoomOutButton.click();map.zoomControl._zoomInButton.click();map._lastCenter;})();");
    //                                ////}
    //                                Thread.Sleep(2000);
    //                            }
    //                            catch
    //                            {
    //                                Console.WriteLine($"Check: coordinates\t{country}\t{city}\t{facility}\t{poi.poiName}");
    //                                File.AppendAllText(pathForExceptions, $"Check: coordinates\t{country}\t{city}\t{facility}\t{poi.poiName}{Environment.NewLine}");

    //                            }


    //                            var consLock = new object();
    //                            lock (consLock)
    //                            {
    //                                //Console.WriteLine(container.Text);
    //                                //Console.WriteLine($"{country}\t{city}\t{facility}\t{poiName}\t{address}\t{email}\t{phone}");
    //                            }

    //                            File.AppendAllText(pathForWrite, $"{country}\t{city}\t{facility}\t{poi.poiName}\t{poi.address}\t{poi.email}\t{poi.phone}\t{poi.openingHours}\t{poi.coordinates}{Environment.NewLine}");
    //                            //File.AppendAllText(pathForWrite, $"{container.Text.Replace('\n', '\t')}{Environment.NewLine}");
    //                        }
    //                        try
    //                        {
    //                            IWebElement allLocator = driver.FindElementById("EmptyPanel").FindElement(By.TagName("h1"));
    //                            Actions actions5 = new Actions(driver);
    //                            actions5.MoveToElement(allLocator);
    //                            Thread.Sleep(1000);
    //                            actions5.Perform();
    //                            Thread.Sleep(1000);
    //                        }
    //                        catch
    //                        {
    //                            Console.WriteLine("++++++++++++++++++++++++++++++++++ НЕ ПЕРЕШЁЛ К \"Locator\" ++++++++++++++++++++++++++++++++++");
    //                        }


    //                        //Console.WriteLine($"{city}\t{facility}\t{resultsInCityText}");
    //                        //File.AppendAllText(pathForWrite, $"\t\t\t\t{city}\t{facility}\t{resultsInCityText}{Environment.NewLine}");

    //                        //Console.WriteLine($"Ошибка: {country}\t{city}\t{facility}");

    //                    }
    //                }
    //                catch
    //                {
    //                    Console.WriteLine($"++++++++++++++++++++++++++++++++++{country} - {facility} - ЧТО-ТО ПОШЛО НЕ ТАК ++++++++++++++++++++++++++++++++++");
    //                    File.AppendAllText(pathForExceptions2, $"++++++++++++++++++++++++++++++++++{country} - {facility} - ЧТО-ТО ПОШЛО НЕ ТАК  ++++++++++++++++++++++++++++++++++{Environment.NewLine}");
    //                    Thread.Sleep(3000);

    //                    IWebElement allLocator2 = driver.FindElementById("EmptyPanel").FindElement(By.TagName("h1"));
    //                    Actions actions6 = new Actions(driver);
    //                    actions6.MoveToElement(allLocator2);
    //                    Thread.Sleep(1000);
    //                    actions6.Perform();
    //                    Thread.Sleep(1000);
    //                    goto mark2;
    //                }
    //            }
    //        }
    //    }




    //    //public void ScrapeChrome(int taskId, List<string> countryList)
    //    //{
    //    //    ChromeDriver driver = new ChromeDriver("D:\\Install");
    //    //    driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");

    //    //    foreach (var country in countryList)
    //    //    {
    //    //        Thread.Sleep(4000);


    //    //        IWebElement inputBoxCountry = driver.FindElementById("sl_country_codes");

    //    //        ////не работает !!! ???
    //    //        //SelectElement clickCity = new SelectElement(inputBox);
    //    //        //clickCity.SelectByText(country);
    //    //        //inputBox.SendKeys(Keys.Enter);  

    //    //        ////можно так:
    //    //        inputBoxCountry.Click();
    //    //        Thread.Sleep(1000);
    //    //        inputBoxCountry.SendKeys(country + Keys.Enter);
    //    //        //inputBox.SendKeys(Keys.Enter);
    //    //        Thread.Sleep(3000);






    //    //    mark:
    //    //        List<string> cityList;

    //    //        try
    //    //        {
    //    //            cityList = driver.FindElementById("main_sl_cities").FindElements(By.TagName("option")).Select(t => t.Text).ToList();
    //    //        }
    //    //        catch
    //    //        {
    //    //            Thread.Sleep(2000);
    //    //            goto mark;
    //    //        }

    //    //        foreach (var city in cityList)
    //    //        {
    //    //            //driver.Navigate().GoToUrl("https://ecobank.com/personal-banking/contact-us/locator");
    //    //            Thread.Sleep(4000);

    //    //            try
    //    //            {
    //    //                IWebElement inputBoxCity = driver.FindElementById("main_sl_cities");
    //    //                inputBoxCity.Click();
    //    //                Thread.Sleep(2000);
    //    //                inputBoxCity.SendKeys(city + Keys.Enter);
    //    //                Thread.Sleep(3000);
    //    //            }
    //    //            catch
    //    //            {

    //    //            }

    //    //            List<string> facilityList = driver.FindElementById("sl_btype").FindElements(By.TagName("option")).Select(t => t.Text).ToList();
    //    //            foreach (var facility in facilityList)
    //    //            {
    //    //                try
    //    //                {
    //    //                    Thread.Sleep(2000);
    //    //                    IWebElement inputFacilityType = driver.FindElementById("sl_btype");
    //    //                    inputFacilityType.Click();
    //    //                    Thread.Sleep(1000);
    //    //                    inputFacilityType.SendKeys(facility);
    //    //                    Thread.Sleep(1000);
    //    //                    inputFacilityType.SendKeys(Keys.Enter);
    //    //                    Thread.Sleep(3000);

    //    //                    SelectElement value = new SelectElement(driver.FindElementById("main_sl_cities"));
    //    //                    string currentCity = value.SelectedOption.Text;
    //    //                    if (currentCity != city)
    //    //                    {
    //    //                        continue;
    //    //                    }
    //    //                    IWebElement resultsInFacility = driver.FindElementById("searchResult");
    //    //                    string resultsInCityText = resultsInFacility.Text;

    //    //                    var consLock = new object();
    //    //                    lock (consLock)
    //    //                    {
    //    //                        Console.WriteLine($"{country}\t{city}\t{facility}\t{resultsInCityText}");
    //    //                    }
    //    //                    string pathForWrite = $@"D:\MV\Программирование\Проекты\Scraper\ScrapEcobank\Ecobank\pois_{taskId}.txt";
    //    //                    File.AppendAllText(pathForWrite, $"{country}\t{city}\t{facility}\t{resultsInCityText}{Environment.NewLine}");
    //    //                    //Thread.Sleep(2000);
    //    //                }
    //    //                catch
    //    //                {

    //    //                }

    //    //            }

    //    //        }
    //    //    }
    //    //}
    //}
}
