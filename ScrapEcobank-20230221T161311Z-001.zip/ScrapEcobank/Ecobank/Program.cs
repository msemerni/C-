﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using AtlasApi;
using AtlasApi.AtlasDataRequestService;
using AtlasApi.AtlasDisplayService;
using AtlasApi.AtlasSelectionService;
using AtlasApi.DataContextService;

namespace Ecobank
{
    class Program
    {
        static void Main(string[] args)
        {
            POI poi = new POI();
            poi.ScrapeChrome();
            Console.ReadKey();
        }
    }
}
