var markers = [
    {
      "name": "Misha",
      "url": "https://en.wikipedia.org/wiki/Canada",
      // 'imgUrl': 'media/semernin.png',
      // "http": "media/semernin.png",
      // "url": "media/semernin.png",
      "lat": -50,
      "lng": 200,    
    },
    {
      "name": "Kosmos",
      "url": "https://en.wikipedia.org/wiki/Anguilla",
      // "http": "media/kosmos.png",
      "lat": -100,
      "lng": 205
    },
 ];

