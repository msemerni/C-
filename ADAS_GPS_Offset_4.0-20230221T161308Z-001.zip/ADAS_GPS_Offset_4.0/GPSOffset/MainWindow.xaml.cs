﻿using AtlasApi;
using AtlasApi.DataContextService;
using AtlasApi.AtlasSelectionService;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using WinForms = System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using System.Runtime.InteropServices;
using System.IO;
using System.Media;
using System.ComponentModel;
using System.Windows.Interop;
using DotSpatial.Positioning;
using AutoUpdaterDotNET;
using System.Diagnostics;

namespace GPSOffset
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        string userName = Environment.UserName;
        //string pathForStatistic = $@"S:\Soft\Intetics_GEO_tools\msemerni\ADAS_GPS_Offset\db_temp\bin\statagps.txt";
        string pathForStatistic = $@"W:\Temp\msemerni\mysoft\bin\statagps.txt";
        int clickCount = 0;
        SettingsWindow settingsWindow;
        DisplayChecks displayChecks;
        
        public MainWindow()
        {
            //// автообновление приложения - Start
            try
            {
                AutoUpdater.InstalledVersion = new Version("4.0");
                AutoUpdater.RunUpdateAsAdmin = false;
                AutoUpdater.Mandatory = true;
                AutoUpdater.UpdateMode = Mode.ForcedDownload;
                AutoUpdater.Start($@"S:\Soft\Intetics_GEO_tools\msemerni\ADAS_GPS_Offset\autoupdater_ADAS_GPS_Offset.xml");
            }
            catch
            {
                MessageBox.Show("Update failed");
            }
            //// автообновление приложения - End

            //// лицензия - Start
            DateTime dateTime = DateTime.Now;
            if (dateTime.Year > 2021)
            {
                MessageBox.Show("Sorry, license expired :(");
                this.Close();
            }
            //// лицензия - End
            
            InitializeComponent();
            settingsWindow = new SettingsWindow();
            displayChecks = new DisplayChecks();
            this.Loaded += LoadUserSettings;
            SwitchToAtlas();
            this.Closing += SaveUserSettings;
        }

        ////////// Help Button - Start добавление кнопки помощи(знак вопроса)на окне //////////
        //private const uint WS_EX_CONTEXTHELP = 0x00000400;
        //private const uint WS_MINIMIZEBOX = 0x00020000;
        //private const uint WS_MAXIMIZEBOX = 0x00010000;
        //private const int GWL_STYLE = -16;
        //private const int GWL_EXSTYLE = -20;
        //private const int SWP_NOSIZE = 0x0001;
        //private const int SWP_NOMOVE = 0x0002;
        //private const int SWP_NOZORDER = 0x0004;
        //private const int SWP_FRAMECHANGED = 0x0020;
        //private const int WM_SYSCOMMAND = 0x0112;
        //private const int SC_CONTEXTHELP = 0xF180;

        //[DllImport("user32.dll")]
        //private static extern uint GetWindowLong(IntPtr hwnd, int index);

        //[DllImport("user32.dll")]
        //private static extern int SetWindowLong(IntPtr hwnd, int index, uint newStyle);

        //[DllImport("user32.dll")]
        //private static extern bool SetWindowPos(IntPtr hwnd, IntPtr hwndInsertAfter, int x, int y, int width, int height, uint flags);

        //protected override void OnSourceInitialized(EventArgs e)
        //{
        //    base.OnSourceInitialized(e);
        //    IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
        //    uint styles = GetWindowLong(hwnd, GWL_STYLE);
        //    styles &= 0xFFFFFFFF ^ (WS_MINIMIZEBOX | WS_MAXIMIZEBOX);
        //    SetWindowLong(hwnd, GWL_STYLE, styles);
        //    styles = GetWindowLong(hwnd, GWL_EXSTYLE);
        //    styles |= WS_EX_CONTEXTHELP;
        //    SetWindowLong(hwnd, GWL_EXSTYLE, styles);
        //    SetWindowPos(hwnd, IntPtr.Zero, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
        //    ((HwndSource)PresentationSource.FromVisual(this)).AddHook(HelpHook);
        //}

        //private IntPtr HelpHook(IntPtr hwnd,
        //        int msg,
        //        IntPtr wParam,
        //        IntPtr lParam,
        //        ref bool handled)
        //{
        //    if (msg == WM_SYSCOMMAND &&
        //            ((int)wParam & 0xFFF0) == SC_CONTEXTHELP)
        //    {
        //        MessageBox.Show("Help");
        //        handled = true;
        //    }
        //    return IntPtr.Zero;
        //}
        ////////// Help Button - End //////////


        ////switch language to EN of another app / переключение на английский язык текущего приложения, там где сейчас фокус!!!!!!!!!!!!!!!//https://stackoverflow.com/questions/19319194/getkeyboardlayoutname-of-other-process
        ////___________________________________________________________________________________________________________________
        StringBuilder Input = new StringBuilder(9);
        [DllImport("user32.dll")]
        static extern uint GetKeyboardLayoutList(int nBuff, [Out] IntPtr[] lpList);
        [DllImport("user32.dll")]
        private static extern IntPtr LoadKeyboardLayout(string pwszKLID, uint Flags);
        [DllImport("user32.dll")]
        static extern bool GetKeyboardLayoutName([Out] StringBuilder pwszKLID);
        [DllImport("user32.dll")]
        static extern IntPtr GetKeyboardLayout(uint idThread);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, IntPtr ProcessId);
        [DllImport("user32.dll")]
        public static extern int ActivateKeyboardLayout(int HKL, int flags);
        [DllImport("user32.dll")]
        private static extern bool PostMessage(int hhwnd, uint msg, IntPtr wparam, IntPtr lparam);
        private static uint WM_INPUTLANGCHANGEREQUEST = 0x0050;
        private static int HWND_BROADCAST = 0xffff;
        private static uint KLF_ACTIVATE = 1;

        public StringBuilder GetInput()
        {
            IntPtr layout = GetKeyboardLayout(GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero));
            ActivateKeyboardLayout((int)layout, 100);
            GetKeyboardLayoutName(Input);
            return Input;
        }

        public void SetInput(string InputID)
        {
            PostMessage(HWND_BROADCAST, WM_INPUTLANGCHANGEREQUEST, IntPtr.Zero, LoadKeyboardLayout(InputID, KLF_ACTIVATE));
        }

        private void SetEnglishInput()
        {
            SetInput("00000409");//United States language keyboarg layout
        }

        private void SwitchToEglishLayoutOnFocusedApp()
        {
            ///// switch language to EN of another app / переключение на английский язык текущего приложения, там где сейчас фокус
            string currentLanguage = GetInput().ToString();
            if (currentLanguage != "00000409")//United States language keyboarg layout
            {
                SetEnglishInput();
            }
        }
        ////___________________________________________________________________________________________________________________
        ///

        private void SwitchToAtlas()
        {
            try
            {
                Interaction.AppActivate("Atlas 2");
                Thread.Sleep(200);
                SwitchToEglishLayoutOnFocusedApp();
                ColdStart();
            }
            catch
            {
                try
                {
                    Interaction.AppActivate("Atlas 1");
                    Thread.Sleep(200);
                    SwitchToEglishLayoutOnFocusedApp();
                    ColdStart();
                }
                catch
                {
                    ////SystemSounds.Hand.Play();
                    ////MessageBox.Show(this, "Atlas/GPS Offset not found");
                }
            }
        }

        private void ColdStart()
        {
            Thread.Sleep(400);
            WinForms.SendKeys.SendWait("%g");
            Thread.Sleep(300);
            Interaction.AppActivate("GPS Offset");
            Thread.Sleep(300);
            WinForms.SendKeys.SendWait("%{F4}");
        }

        private void ApplyGPSOffset(string text)
        {
            Thread.Sleep(200);
            WinForms.SendKeys.SendWait("%g");
            Thread.Sleep(300);
            WinForms.SendKeys.SendWait("{Del 5}");
            Thread.Sleep(200);
            WinForms.SendKeys.SendWait(text);
            Thread.Sleep(200);
            WinForms.SendKeys.SendWait("{Enter}");
        }

        private string GetText(object sender)
        {
            return ((Button)sender).Content.ToString().Replace(",", ".");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Interaction.AppActivate("Atlas 2");
                Thread.Sleep(300);
                SwitchToEglishLayoutOnFocusedApp();
                ApplyGPSOffset(GetText(sender));
            }
            catch
            {
                try
                {
                    Interaction.AppActivate("Atlas 1");
                    Thread.Sleep(300);
                    SwitchToEglishLayoutOnFocusedApp();
                    ApplyGPSOffset(GetText(sender));
                }
                catch
                {
                    SystemSounds.Hand.Play();
                    MessageBox.Show(this, "Atlas/GPS Offset not found!");
                }
            }

            clickCount++;
            clickCounter.Text = clickCount.ToString();
            try
            {
                writeStatistic(sender);
            }
            catch
            {
            }
        }

        private void writeStatistic(object sender)
        {
            using (StreamWriter writetext = new StreamWriter(pathForStatistic, true))
            {
                writetext.WriteLine($"{DateTime.Now.ToString("dd-MM-yyyy")}\t{userName}\t{AutoUpdater.InstalledVersion}\t{GetText(sender)}");
                //writetext.WriteLine($"{DateTime.Now.ToString("dd-MM-yyyy")}\t{userName}\t{Application.Current.MainWindow.Title}\t{GetText(sender)}");
            }
        }


        /////////////////////////////////// применение сорс кода - начало
        string myDate;

        private void ApplyChanges(object sender, RoutedEventArgs e)
        {
            try
            {
                //NavLink navlink = new NavLink();
                DataService ds = new DataService();
                //Atlas atlas = new Atlas();
               
                //atlas.zoomIn();
                //Thread.Sleep(1000);
                //atlas.selectLinkByPvids("912928517", true);
                //var ls = ds.getNavLinkByLinkPvid(912928517);

                int mySource = Int32.Parse(sourceDF.Text);
                //string myDate = "20" + sourceDF.Text[0].ToString() + sourceDF.Text[1].ToString() + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();

                //adasText.ItemsSource = Enum.GetValues(typeof(adas)).Cast<adas>();
                //adasText.ItemsSource = enumval.ToList();

                //// применение сорс даты  - Start
                if (sourceDF.Text[0] != '3')
                    myDate = "20" + sourceDF.Text[0].ToString() + sourceDF.Text[1].ToString() + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '0')
                    myDate = "2020" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '1')
                    myDate = "2021" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '2')
                    myDate = "2022" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '3')
                    myDate = "2023" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '4')
                    myDate = "2024" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                else if (sourceDF.Text[0] == '3' && sourceDF.Text[1] == '5')
                    myDate = "2025" + sourceDF.Text[2].ToString() + sourceDF.Text[3].ToString();
                //// применение сорс даты  - End

                //get pvids
                SelectionService ss = new SelectionService();
                string pvids = ss.getAtlasSelection();
                // select pvids
                //SelectionService ss = new SelectionService();
                //ss.deSelectAll();
                ss.selectLinkByPvids(pvids, true);

                //NavLink navlink = new NavLink();
                //texbox.Text = navlink.geometrySource.ToString();
                NavLink[] navlinks = ds.getNavLinksByLinkPvids(pvids);


                foreach (var navlink1 in navlinks)
                {
                    ////////////////////////////////
                    //var ext = navlink1.extendedAttributes.FirstOrDefault().attrValue;
                    //ExtendedAttribute extAttr = new ExtendedAttribute();
                    //var navlinksext = navlink1.extendedAttributes[0];
                    //var trel = navlink1.toRefExtendedLanes=get; удалить
                    //var ex = extAttr.attrValue;
                    //var er = navlink1.extendedAttributes.GetValue(0);
                    ///////////////////////////////
                    //if (navlink1.geometrySource.ToString().Substring(4)!= "9462")
                    //{
                    //    MessageBox.Show("Check GeoSource");
                    //}
                    ///////////////////////////////


                    //////// Update Geometry source - Start
                    if (settingsWindow.flagUpdateGeoSource.IsChecked == true)
                    {
                        navlink1.geometrySource = mySource;
                    }
                    else if (settingsWindow.flagUpdateGeoSource.IsChecked == null)
                    {
                        if (navlink1.geometrySource <= mySource || navlink1.geometrySource.ToString().Substring(0, 1) == "2")
                        {
                            navlink1.geometrySource = mySource;
                        }
                    }
                    //////// Update Geometry source - End

                    //////// Update Lane Cat source - Start
                    if (settingsWindow.flagUpdateLaneCatSource.IsChecked == true)
                    {
                        navlink1.numberLanesSource = mySource;
                    }
                    else if (settingsWindow.flagUpdateLaneCatSource == null)
                    {
                        if (navlink1.numberLanesSource <= mySource || navlink1.numberLanesSource.ToString().Substring(0, 1) == "2")
                        {
                            navlink1.numberLanesSource = mySource;
                        }
                    }
                    //////// Update Lane source - End

                    //////// Update Number of Lanes - Start
                    if (settingsWindow.flagUpdateNumberOfLanes.IsChecked == true)
                    {
                        navlink1.fromRefNumberLanes = Int32.Parse(lanesFrom.Text);
                        navlink1.toRefNumberLanes = Int32.Parse(lanesTo.Text);
                    }
                    //////// Update Number of Lanes - End

                    //////// Update Lane Category - Start
                    if (settingsWindow.flagUpdateLaneCategory.IsChecked == true)
                    {
                        int[] temp = { navlink1.fromRefNumberLanes, navlink1.toRefNumberLanes };
                        if (temp.Max() < 2)
                            navlink1.laneCategory = 49;
                        else if (temp.Max() > 3)
                            navlink1.laneCategory = 51;
                        else
                            navlink1.laneCategory = 50;
                    }
                    //////// Update Lane Category - End

                    //////// Update DOT source - Start
                    if (settingsWindow.flagUpdateDotSource.IsChecked == true)
                    {
                        navlink1.dirOfTravelSource = mySource;
                    }
                    else if (settingsWindow.flagUpdateDotSource.IsChecked == null)
                    {
                        if (navlink1.dirOfTravelSource <= mySource || navlink1.dirOfTravelSource.ToString().Substring(0, 1) == "2")
                        {
                            navlink1.dirOfTravelSource = mySource;
                        }
                    }
                    //////// Update DOT source - End

                    //////// Update ADAS - Start
                    if (settingsWindow.flagUpdateADAS.IsChecked == true)
                    {
                        if (adasCategory.Text == "ADAS COMPLIANT")
                            navlink1.adasPrecisionCategory = "1";
                        else if (adasCategory.Text == "NOT ADAS COMPLIANT")
                            navlink1.adasPrecisionCategory = "0";
                    }

                    if (settingsWindow.flagUpdateAdasSource.IsChecked == true)
                    {
                        if (adasSource.Text == "CONSTRUCTION")
                            navlink1.adasGeometrySource = 94;
                        else if (adasSource.Text == "GPS DATA")
                            navlink1.adasGeometrySource = 48;
                        else if (adasSource.Text == "GPS IMPLIED")
                            navlink1.adasGeometrySource = 79;
                        else if (adasSource.Text == "IMU")
                            navlink1.adasGeometrySource = 97;
                        else if (adasSource.Text == "NO CORRECTION")
                            navlink1.adasGeometrySource = 95;
                        else if (adasSource.Text == "NO GPS SIGNAL")
                            navlink1.adasGeometrySource = 96;
                        else if (adasSource.Text == "PP IMU")
                            navlink1.adasGeometrySource = 49;
                        else if (adasSource.Text == "IMPASSABLE")
                            navlink1.adasGeometrySource = 98;
                        else if (adasSource.Text == "UNASSIGNED")
                            navlink1.adasGeometrySource = 93;
                        else if (adasSource.Text == "N/A")
                            navlink1.adasGeometrySource = 0;
                    }

                    if (settingsWindow.flagUpdateAdasDate.IsChecked == true)
                    {
                        navlink1.adasGeometryDate = Int32.Parse(myDate);

                    }
                    //////// Update ADAS - End

                    /////////////////////////////////////////////////////////////////////
                    //navlink1.fromRefExtendedLanes = 3; удалить
                    //navlink1.toRefExtendedLanes = get; удалить
                    //var dir = navlink1.directionOfTravel.Value;

                    //if (navlink1.directionOfTravel.Value.ToString() == "TO_REF")
                    //{
                    //    navlink1.toRefExtendedLanes = navlink1.toRefNumberLanes + 1;
                    //    //navlink1.toRefExtendedLanes = 0;
                    //}

                    //var ttr = navlink1.extendedAttributes.Count();

                    //var ttr = navlink1.extendedAttributes.Contains();

                    //navlink1.fromRefExtendedLanes = navlink1.fromRefNumberLanes + 1;
                    //navlink1.fromRefExtendedLanes = 0;
                    /////////////////////////////////////////////////////////////////////

                    ds.updateNavLink(navlink1);

                }
                ss.deSelectAll();
                ss.selectLinkByPvids("1", false);
                ss.selectLinkByPvids(pvids, false);

                Thread.Sleep(500);

                try
                {
                    writeStatistic(sender);
                }
                catch
                {
                }
            }
            catch
            {
            }

        }
        /////////////////////////////////// применение сорс кода - конец


        private void TextBox_KeyUp(object sender, KeyEventArgs ek)
        {
            if (ek.Key == Key.Enter)
            {
                myGrid2.Visibility = Visibility.Hidden;
            }
            //if (ek.Key == Key.Escape)
            //{
            //    myGrid2.Visibility = Visibility.Hidden;
            //}
        }

        private void CalculateAndFillOffsetValue()
        {
            while (true)
            {
                if (double.TryParse(defaultLaneWidth.Text.Replace(",", "."), out double defaultLaneValue))
                {
                    ////double defaultLaneValue = Double.Parse(defaultLaneWidth.Text.Replace(",", "."));
                    textBoxA.Text = (defaultLaneValue * -2).ToString();
                    textBoxB.Text = (defaultLaneValue * -1.5).ToString();
                    textBoxC.Text = (defaultLaneValue * -1).ToString();
                    textBoxD.Text = (defaultLaneValue * -0.5).ToString();
                    textBoxE.Text = "0.01";
                    textBoxF.Text = (defaultLaneValue * 0.5).ToString();
                    textBoxG.Text = (defaultLaneValue).ToString();
                    textBoxH.Text = (defaultLaneValue * 1.5).ToString();
                    textBoxI.Text = (defaultLaneValue * 2).ToString();
                    ////defaultLaneWidthExpander.IsExpanded = false;
                    break;
                }
                else
                {
                    defaultLaneWidth.Text = null;
                    //MessageBox.Show("Input the number");
                    defaultLaneWidthExpander.IsExpanded = true;
                    break;
                }
            }
        }

        private void defaultLaneWidth_KeyUp(object sender, KeyEventArgs ed)
        {
            if (ed.Key == Key.Enter)
            {
                CalculateAndFillOffsetValue();
                defaultLaneWidthExpander.IsExpanded = false;
            }
        }
        private void defaultLaneWidthExpander_Collapsed(object sender, RoutedEventArgs e)
        {
            CalculateAndFillOffsetValue();
        }

        private void Button_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            myGrid2.Visibility = Visibility.Visible;
        }

        private void ResetToDefaultOffset_Click(object sender, RoutedEventArgs e)
        {

            CalculateAndFillOffsetValue();

            try
            {
                writeStatistic(sender);
            }
            catch
            {
            }
        }

        //// Сохранение настроек юзера - Start
        private void LoadUserSettings(object sender, EventArgs e)
        {
            //textBoxA.Text = Properties.Settings.Default.textBoxA_user;
            //textBoxB.Text = Properties.Settings.Default.textBoxB_user;
            //textBoxC.Text = Properties.Settings.Default.textBoxC_user;
            //textBoxD.Text = Properties.Settings.Default.textBoxD_user;
            //textBoxE.Text = Properties.Settings.Default.textBoxE_user;
            //textBoxF.Text = Properties.Settings.Default.textBoxF_user;
            //textBoxG.Text = Properties.Settings.Default.textBoxG_user;
            //textBoxH.Text = Properties.Settings.Default.textBoxH_user;
            //textBoxI.Text = Properties.Settings.Default.textBoxI_user;
            defaultLaneWidth.Text = Properties.Settings.Default.defaultLaneWidth_user;
        }
        //// Сохранение настроек юзера - End

        //// Загрузка настроек юзера - Start
        private void SaveUserSettings(object sender, CancelEventArgs e)
        {
            //Properties.Settings.Default.textBoxA_user = textBoxA.Text;
            //Properties.Settings.Default.textBoxB_user = textBoxB.Text;
            //Properties.Settings.Default.textBoxC_user = textBoxC.Text;
            //Properties.Settings.Default.textBoxD_user = textBoxD.Text;
            //Properties.Settings.Default.textBoxE_user = textBoxE.Text;
            //Properties.Settings.Default.textBoxF_user = textBoxF.Text;
            //Properties.Settings.Default.textBoxG_user = textBoxG.Text;
            //Properties.Settings.Default.textBoxH_user = textBoxH.Text;
            //Properties.Settings.Default.textBoxI_user = textBoxI.Text;
            Properties.Settings.Default.defaultLaneWidth_user = defaultLaneWidth.Text;
            Properties.Settings.Default.Save();
        }
        //// Загрузка настроек юзера - End
        
        //// Открытие кнопи информации Info - Start
        private void CommandHelp_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show(@"Your ads could be here
___________________________________________________________

GPS offset:
  'Left click' - apply GPS offset
  'Right click' - change GPS offset (Enter - apply changes)
  'Reset' - reset GPS offset to default settings
Update source:
  'Update' - update source code specified in the 'Settings'
___________________________________________________________
Written by Mykhailo Semernin - 2020");

            try
            {
                writeStatistic(sender);
            }
            catch
            {
            }
        }
        //// Открытие кнопи информации Info - Start
        
        //// Обработчик нажатия кнопки "Настройки" - Start
        private void CommandSettings_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            settingsWindow.Owner = this;

            var scrHeight = System.Windows.SystemParameters.PrimaryScreenHeight;
            if (this.Top <= scrHeight / 2)
                settingsWindow.Top = this.Top + this.Height;
            else
                settingsWindow.Top = this.Top - settingsWindow.Height - 7;
            settingsWindow.Left = (this.Left + this.Width / 2) - settingsWindow.Width / 2;

            settingsWindow.Show();
        }
        //// Обработчик нажатия кнопки "Настройки" - End

        //// Разворачивание панели применения адас и сорсов - Start
        private void ShowAdasPanel_Expanded(object sender, RoutedEventArgs e)
        {
            adasPanel.Visibility = Visibility.Visible;
            this.Height = 88;
        }

        private void ShowAdasPanel_Collapsed(object sender, RoutedEventArgs e)
        {
            adasPanel.Visibility = Visibility.Collapsed;
            this.Height = 65;
        }

        private void openDisplayChecks_Click(object sender, RoutedEventArgs e)
        {
            displayChecks.Owner = this;
            displayChecks.Show();
        }
        //// Разворачивание панели применения адас и сорсов - End

        ////////////


        //private void Login_Click(object sender, RoutedEventArgs e)
        //{
        //    if (settingsWindow.ShowDialog() == true)
        //    {
        //        MessageBox.Show("Настройки применены");
        //    }
        //    else
        //    {
        //        MessageBox.Show("Отмена");
        //    }
        //}

        //private void FlagChangeGeoSource_Checked(object sender, RoutedEventArgs e)
        //{
        //    //sourceDF.IsEnabled = true;
        //}
        //private void FlagChangeGeoSource_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    sourceDF.IsEnabled = false;
        //}

        //enum adas
        //{
        //    ADAS_COMPLIANT,
        //    NOT_ADAS_COMPLIANT
        //}

        //enum adasSource
        //{
        //    NA,
        //    CONSTRUCTION,
        //    GPS_DATA,
        //    GPS_IMPLIED,
        //    IMU,
        //    NO_CORRECTION,
        //    NO_GPS_SIGNAL,
        //    PP_IMU,
        //    IMPASSABLE,
        //    UNASSIGNED
        //}



    }
}
