﻿using AtlasApi.AtlasSelectionService;
using AtlasApi.DataContextService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GPSOffset
{
    /// <summary>
    /// Interaction logic for DisplayChecks.xaml
    /// </summary>
    public partial class DisplayChecks : Window
    {
        public DisplayChecks()
        {
            InitializeComponent();
        }

        private void buttonCheck_Click(object sender, RoutedEventArgs e)
        {
            Check_FC();
        }

        private void Check_FC()
        {
            //NavLink navlinkForCheck = new NavLink();
            SelectionService sServ = new SelectionService();
            DataService dServ = new DataService();
            List<string> exceptionList = new List<string>();

            string pvidsForCheck = sServ.getAtlasSelection();
            ////sServ.selectLinkByPvids(pvidsForCheck, true);
            NavLink[] navlinksForCheck = dServ.getNavLinksByLinkPvids(pvidsForCheck);
            ////NavLink[] navlinksForCheckResult;

            //// List<Link> result = (List<Link>)yourList.Where(link => link.functionalClass == 2);
            ///
            foreach (var navlink in navlinksForCheck)
            {
                if (navlink.functionalClass == 2 && navlink.adasPrecisionCategory != "1")
                {
                    var linkPVID = navlink.linkPvid.ToString();
                    exceptionList.Add(linkPVID);
                }
            }

            string exeptionsString = string.Join(",", exceptionList);

            sServ.deSelectAll();
            sServ.selectLinkByPvids("1", false);
            sServ.selectLinkByPvids(exeptionsString, false);

            Thread.Sleep(500);
        }
        private void ShowExceptionsResult()
        {
        }
    }
}
